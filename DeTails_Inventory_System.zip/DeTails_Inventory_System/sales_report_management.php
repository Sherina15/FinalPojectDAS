<?php 
session_start();
if (!isset($_SESSION['username'])) 
{
    header('Location: login.php'); 
    exit();
}

$username = htmlspecialchars($_SESSION['username']);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "details_inventory_management";

$connection = new mysqli($servername, $username, $password, $dbname);

if ($connection->connect_error) 
{
    die("Connection Failed: " . $connection->connect_error);
}

$sales_query = "SELECT id, product_name, quantity AS quantity, price, (quantity * price) AS subtotal FROM purchase_management";
$sales_result = $connection->query($sales_query);

$total_amount = 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Report</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body 
        {
            background-color: #f8f9fa; 
            color: #343a40; 
            font-family: 'Poppins', sans-serif; 
        }

        .container 
        {
            max-width: 800px; 
            margin: 50px auto; 
            padding: 20px; 
            border: 1px solid #000; 
            border-radius: 8px; 
            background-color: #fff; 
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); 
        }

        h1 
        {
            font-weight: 600; 
            color: #000; 
            text-align: center; 
        }

        h3 
        {
            text-align: center; 
        }

        .table 
        {
            margin-top: 20px; 
            background-color: #fff; 
            border: 1px solid #000; 
        }

        .table th 
        {
            background-color: #000; 
            color: #fff; 
        }

        .table td 
        {
            background-color: #ffffff; 
            color: #000000; 
        }

        tr:hover td 
        {
            background-color: #f2f2f2; 
        }

        .table-responsive 
        {
            max-height: 400px; 
            overflow-y: scroll; 
        }
    </style>
</head>
<body>
<div class="container">
    <h1 class="mt-4">Sales Report</h1>

    <div class="table-responsive mt-4">
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Purchase Item</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Price</th>
                    <th scope="col">Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($sales_result->num_rows > 0) 
                {
                    while ($row = $sales_result->fetch_assoc()) 
                    {
                        $subtotal = $row['subtotal'];
                        $total_amount += $subtotal; 
                        ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['id']); ?></td>
                            <td><?php echo htmlspecialchars($row['product_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['quantity']); ?></td>
                            <td><?php echo number_format($row['price'], 2); ?></td>
                            <td><?php echo number_format($subtotal, 2); ?></td>
                        </tr>
                        <?php
                    }
                } 
                else 
                {
                    echo '<tr><td colspan="5" class="text-center">No sales record found</td></tr>';
                }
                ?>
            </tbody>
        </table>
    </div>

    <h3 class="mt-4">Total of All Items: <?php echo number_format($total_amount, 2); ?></h3>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
$connection->close();
?>