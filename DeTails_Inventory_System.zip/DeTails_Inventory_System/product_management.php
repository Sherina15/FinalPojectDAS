<?php 
session_start();
include('product_management_header.php');

if (!isset($_SESSION['username'])) {
    header('Location: login.php'); 
    exit();
}

$username = htmlspecialchars($_SESSION['username']);

?>  
<link rel="stylesheet" href="product_management.css">
<div class="modal fade" id="insertdata" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="insertdataLabel" aria-hidden="true">
  	<div class="modal-dialog">
    	<div class="modal-content">
     		<div class="modal-header">
        		<h1 class="modal-title fs-5" id="insertdataLabel">Add Product</h1>
        		<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      		</div>
	      	<form action="product_management_function.php" method="POST">
		      	<div class="modal-body">

			      	<div class="form-group ">
			      		<label for="">Product Name</label>
			                <input type ="text" name="product_name" class="form-control" placeholder="Enter Product" required pattern="\S.*">
			      	</div>

			      	<div class="form-group">
			      		<label for="">Category</label><br>
		 				<select id="category" name="category" required>
				            <option value="">Select a category</option>
				            <option value="Pet Food">Pet Food</option>
				            <option value="Pet Health Care">Pet Health Care</option>
				            <option value="Pet Grooming">Pet Grooming</option>
				            <option value="Home Care and Supplies">Home Care and Supplies</option>
				            <option value="Pet Accessories">Pet Accessories</option>
				        </select>
			      	</div>
			        <div class="form-group ">
			            <label for="">Quantity</label>
			                <input type = "number" name="quantity" min="1" class="form-control" placeholder="Enter Quantity" required>
			        </div>

			        <div class="form-group ">
			            <label for="">Price</label>
			                <input type = "number" name="price" min="1" class="form-control" placeholder="Enter Price" required>
			        </div>
		      	</div>
			      	<div class="modal-footer">
				        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
				        <button type="submit" name="save_data" class="btn btn-primary">Add Product</button>
			      	</div>
	  		</form>
    	</div>
  	</div>
</div>


<div class="modal fade" id="viewproduct" tabindex="-1" aria-labelledby="viewproductLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="viewproductLabel">View Product</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        	<div class="view_product_data"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>




<div class="modal fade" id="editproduct" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="editproductLabel" aria-hidden="true">
  	<div class="modal-dialog">
    	<div class="modal-content">
     		<div class="modal-header">
        		<h1 class="modal-title fs-5" id="editproductLabel">Edit Product</h1>
        		<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      		</div>
	      	<form action="product_management_function.php" method="POST">
		      	<div class="modal-body">

		      		<div class="form-group ">
			                <input type = "hidden" name="id" class="form-control" id='product_id'>
			      	</div>

			      	<div class="form-group ">
			            <label for="">Quantity</label>
			                <input type = "number" name="quantity" id="quantity" min="1" class="form-control" placeholder="Enter Quantity">
			        </div>

			        <div class="form-group ">
			            <label for="">Price</label>
			                <input type = "number" name="price" id="price" min="1" class="form-control" placeholder="Enter Price">
			        </div>
			        <div class="form-group ">
			            
			                <input type = "hidden" name="date" id="date" class="form-control">
			        </div>

			       
		      	</div>
			      	<div class="modal-footer">
				        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
				        <button type="submit" name="update_product" class="btn btn-primary">Update Product</button>
			      	</div>
	  		</form>
    	</div>
  	</div>
</div>


<div class="container mt-5">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<?php
			 	if (isset($_SESSION['status']) && $_SESSION['status'] != '')
			 	{

			 	?>
					<div class="alert alert-warning alert-dismissible fade show" role="alert">
  						<strong></strong> <?php echo $_SESSION['status']; ?>
  						<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
					</div>
				<?php
			 		unset($_SESSION['status']);
			 	}
				?>
				<div class="card">
					<div class="card-header">
						<h4>Product List</h4>
						<button type="button" class="btn btn-primary float-end" data-bs-toggle="modal" data-bs-target="#insertdata ">
  						Add Product
						</button>
					</div>
						<div class="card-body">
							<div style="max-height: 400px; overflow-y: scroll;">

								<div class="search-sort-container">
            						<div class="search"> 
               						 	<input id="search" type="text" name="search" placeholder="Search" class="form-control">
            						</div>

									<table class="table table-striped table-bordered table-sortable" id="data">
									    <thead>
										       <tr>
										            <th scope="col">ID</th>
										            <th scope="col">Product Name</th>
										            <th scope="col">Category</th>
										            <th scope="col">Quantity</th>
										            <th scope="col">Price</th>
										            <th scope="col">Date Added</th>
										            <th scope="col">Updated Date</th>
										            <th scope="col">View</th>
										            <th scope="col">Edit</th>
										            <th scope="col">Delete</th>
										        </tr>
									    	</thead>
									    <tbody>
									        <?php
									            
									            $servername = "localhost";
									            $username = "root";
									            $password = "";
									            $dbname = "details_inventory_management";

									            $connection = new mysqli($servername, $username, $password, $dbname);

									            if ($connection->connect_error) 
									            {
									                die("Connection Failed: " . $connection->connect_error);
									            }

									            $fetch_query = "SELECT * FROM product_management";
									            $fetch_query_run = mysqli_query($connection, $fetch_query);

									            if (mysqli_num_rows($fetch_query_run) > 0) 
									            {
									                while ($row = mysqli_fetch_array($fetch_query_run)) 
									                {
									                    ?>
									                    <tr>
									                        <td class="product_id"><?php echo htmlspecialchars($row['id']); ?></td>
									                        <td class="account_name"><?php echo htmlspecialchars($row['product_name']); ?></td>
									                        <td><?php echo htmlspecialchars($row['category']); ?></td>
									                        <td><?php echo htmlspecialchars($row['quantity']); ?></td>
									                        <td><?php echo htmlspecialchars($row['price']); ?></td>
									                        <td><?php echo htmlspecialchars($row['date_added']); ?></td>
									                        <td><?php echo htmlspecialchars($row['updated_at']); ?></td> 
									                        <td>
									                            <a href="#" class="btn btn-info btn-sm view_product">View Data</a>
									                        </td>
									                        <td>
									                            <a href="#" class="btn btn-info btn-sm edit_product"><i class='bx bx-edit-alt'></i></a>
									                        </td>
									                        <td>
									                            <a href="#" class="btn btn-info btn-sm delete_button">Remove</a>
									                        </td>
									                    </tr>
									                    <?php
									                }
									            } 
									            else 
									            {
									                ?>
									                <tr>
									                    <td colspan="10" class="text-center">No record found</td>
									                </tr>
									                <?php
									            }
									            $connection->close();
									        ?>
									    </tbody>
									</table>
							  </div>
						 </div>
					</div>
			  </div>
		</div>
	</div>
</div>


<?php include('product_management_footer.php');?>

<script>
	
$(document).ready(function()
{
    $('.view_product').click(function (e)
    {
        e.preventDefault();

        var product_id = $(this).closest('tr').find('.product_id').text();

        $.ajax({
            method: "POST",
            url: "product_management_function.php",
            data: {
                'click_view_btn': true,
                'product_id': product_id,
            },
            success: function (response)
            {
                $('.view_product_data').html(response);
                $('#viewproduct').modal('show');
            }
        });
    });
});





$(document).ready(function()
{
	$('.edit_product').click(function (e)
	{
		e.preventDefault();

		var product_id = $(this).closest('tr').find('.product_id').text();
	$.ajax({
		method: "POST",
		url: "product_management_function.php",
		data: {
			'click_edit_btn':true,
			'product_id': product_id,
		},
		success: function (response)
		{

			$.each(response, function(key, value)
			{
				$('#product_id').val(value['id']);
				$('#quantity').val(value['quantity']);
				$('#price').val(value['price']);
				$('#date').val(value['date']);
			});
			
		$('#editproduct').modal('show');
		}
	});
	});
});




$(document).ready(function()
{
	$('.delete_button').click(function (e)
	{
		e.preventDefault();
		
	var product_id = $(this).closest('tr').find('.product_id').text();
		
		$.ajax({
		method: "POST",
		url: "product_management_function.php",
		data: {
			'click_delete_btn':true,
			'product_id': product_id,
		},
		success: function (response)
		{
			
				console.log(response);
				window.location.reload();			
		}	
		
	});

	});
});


$(document).ready(function() 
{
    
    $('#search').keyup(function() 
    {
        search_table($(this).val());
    });

    
    function search_table(value) 
    {
        
        $('#data tr').each(function() 
        {
            var found = false; 

            
            $(this).find('td').each(function() {
                var cellText = $(this).text().toLowerCase(); 
                var searchValue = value.toLowerCase(); 

                
                if (cellText.indexOf(searchValue) >= 0)
                {
                    found = true; 
                }
            });

            if (found === true) 
            {
                $(this).show();
            } 
            else 
            {
                $(this).hide();
            }
        });
    }
});


function sortTableByColumn(table, column, asc = true) 
{
    const dirModifier = asc ? 1 : -1;
    const tBody = table.tBodies[0];
    const rows = Array.from(tBody.querySelectorAll("tr"));

 
    const sortedRows = rows.sort((a, b) => {
        const aColText = a.querySelector(`td:nth-child(${column + 1})`).textContent.trim().toLowerCase();  // Convert to lowercase
        const bColText = b.querySelector(`td:nth-child(${column + 1})`).textContent.trim().toLowerCase();  // Convert to lowercase

    
        const aColValue = isNaN(aColText) ? aColText : parseFloat(aColText);
        const bColValue = isNaN(bColText) ? bColText : parseFloat(bColText);

        return aColValue > bColValue ? (1 * dirModifier) : (-1 * dirModifier);
    });

    
    while (tBody.firstChild) 
    {
        tBody.removeChild(tBody.firstChild);
    }

    tBody.append(...sortedRows);

    table.querySelectorAll("th").forEach(th => th.classList.remove("th-sort-asc", "th-sort-desc"));

 
    table.querySelector(`th:nth-child(${column + 1})`).classList.toggle("th-sort-asc", asc);
    table.querySelector(`th:nth-child(${column + 1})`).classList.toggle("th-sort-desc", !asc);
}

document.querySelectorAll(".table-sortable th").forEach(headerCell => {
    headerCell.addEventListener("click", () => {
        const tableElement = headerCell.closest("table");
        const headerIndex = Array.prototype.indexOf.call(headerCell.parentElement.children, headerCell);
        const currentIsAscending = headerCell.classList.contains("th-sort-asc");

        sortTableByColumn(tableElement, headerIndex, !currentIsAscending);
    });
});

</script>
