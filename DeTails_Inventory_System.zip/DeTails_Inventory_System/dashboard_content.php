<?php

session_start(); 

if (!isset($_SESSION['username'])) 
{
    header('Location: login.php'); 
    exit();
}

$username = htmlspecialchars($_SESSION['username']);

$connection = new mysqli("localhost", "root", "", "details_inventory_management");

if ($connection->connect_error) 
{
    die("Connection failed: " . $connection->connect_error);
}

$totalStocksQuery = "SELECT SUM(quantity) AS total_stocks FROM product_management";
$lowStocksQuery = "SELECT COUNT(*) AS low_stocks FROM product_management WHERE quantity < 10 AND quantity > 0";

$totalStocksResult = $connection->query($totalStocksQuery)->fetch_assoc();
$lowStocksResult = $connection->query($lowStocksQuery)->fetch_assoc();

$totalStocks = $totalStocksResult['total_stocks'] ?? 0;
$lowStocks = $lowStocksResult['low_stocks'] ?? 0;

$sales_query = "SELECT product_name, quantity AS quantity, price FROM purchase_management";
$sales_result = $connection->query($sales_query);

$products = [];
$quantities = [];
$total_amount = 0;

if ($sales_result->num_rows > 0) 
{
    while ($row = $sales_result->fetch_assoc()) 
    {
        $products[] = $row['product_name'];
        $quantities[] = $row['quantity'];
        $total_amount += $row['quantity'] * $row['price'];
    }
} 
else 
{
    $products[] = 'No sales';
    $quantities[] = 0;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body 
        {
            background-color: #f8f9fa;
        }
        .card 
        {
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h1, h5 
        {
            color: #343a40;
        }
        #salesChart 
        {
            max-width: 600px;
            height: 300px;
        }
        .chart-container 
        {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="navbar-nav ml-auto"> 
            <span class="navbar-text">
                Welcome, <?php echo htmlspecialchars($username); ?> 
            </span>
        </div>
    </nav>
<div class="container mt-4">
    <h1 class="text-center"></h1>
    
    <div class="row mt-4 justify-content-center">
        <div class="col-md-4">
            <div class="card bg-light">
                <div class="card-body text-center">
                    <h5>Total Product Stocks</h5>
                    <p class="display-4"><?php echo $totalStocks; ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-light">
                <div class="card-body text-center">
                    <h5>Low Stocks</h5>
                    <p class="display-4"><?php echo $lowStocks; ?></p>
                </div>
            </div>
        </div>
    </div>

    <div class="chart-container mt-4">
        <div class="card" style="background-color: #ffffff;">
            <div class="card-body text-center">
                <h5>Sales Report</h5>
                <canvas id="salesChart"></canvas>
                <h3 class="mt-4">Total Sales Amount: <?php echo number_format($total_amount, 2); ?></h3>
            </div>
        </div>
    </div>
</div>

<script>
    const ctx = document.getElementById('salesChart').getContext('2d');
    const salesChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($products); ?>,
            datasets: [{
                label: 'Quantity Sold',
                data: <?php echo json_encode($quantities); ?>,
                backgroundColor: 'rgba(54, 162, 235, 0.6)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>

<?php
$connection->close();
?>